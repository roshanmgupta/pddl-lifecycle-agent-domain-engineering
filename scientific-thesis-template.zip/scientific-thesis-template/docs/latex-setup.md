# Recommended LaTeX environments

The recommended setup is **Docker** for compiling and **VS Code** for editing.
Both are described in the main README; this page adds the details, platform-specific installation hints, and the TeXstudio alternative.

## LaTeX distribution

Choose one of the two setups: Docker-based (recommended) or traditional.

### Docker-based (recommended)

The [TeX Live docker image by the Island of TeX](https://gitlab.com/islandoftex/images/texlive#tex-live-docker-image) provides a perfectly configured LaTeX distribution with all required tools.
It works the same on Windows, macOS, and Linux and ships `latexmk`, `biber`, `latexindent`, Python, and `latexminted`.
Thus, `minted` works without further setup - also on Windows.
The generated `Dockerfile` is based on that image; see [Usage with docker](../README.md#usage-with-docker) in the main README.

1. Install Docker: [Docker Desktop](https://docs.docker.com/desktop/) on Windows and macOS, [Docker Engine](https://docs.docker.com/engine/install/) on Linux.
   On Linux, follow the [post-installation steps](https://docs.docker.com/engine/install/linux-postinstall/) to run `docker` without `sudo`.
1. Execute `docker pull registry.gitlab.com/islandoftex/images/texlive:latest`.
   This downloads approx. 3 GB.
1. Compile on the command line: open a terminal in the directory of your document and run the command for your system.
   Replace `main-english` by the main file you use.

   Windows (PowerShell):

   ```powershell
   docker run --rm -v "${PWD}:/workdir" registry.gitlab.com/islandoftex/images/texlive:latest latexmk main-english
   ```

   Windows (Command Prompt):

   ```cmd
   docker run --rm -v "%cd%:/workdir" registry.gitlab.com/islandoftex/images/texlive:latest latexmk main-english
   ```

   Linux and macOS:

   ```shell
   docker run --rm -v "$PWD:/workdir" registry.gitlab.com/islandoftex/images/texlive:latest latexmk main-english
   ```

To compile from an editor, see [VS Code](#vs-code-as-latex-editor) (recommended) or [TeXstudio](#using-texstudio-with-the-docker-image).

### Traditional

Install a LaTeX distribution on your machine: [MiKTeX](https://miktex.org/download) on Windows, [TeX Live](https://www.tug.org/texlive/) on macOS and Linux.

#### Installation hints for Windows

Note: The default installation of MiKTeX might ship with incompatible biblatex and biber packages.
**You have to keep your MiKTeX up to date.**
In case you followed the linked installation steps, you only have to run "Update MiKTeX".
If you installed MiKTeX other ways, you have to run "Update MiKTeX (Admin)" and "Update MiKTeX" and check in both tools for updates (see <http://tex.stackexchange.com/a/108490/9075>).

##### Preparations

1. Install [chocolatey]:
    1. Open `cmd.exe` as Administrator
    2. Paste and hit <kbd>Enter</kbd> `@"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -InputFormat None -ExecutionPolicy Bypass -Command "iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))" && SET "PATH=%PATH%;%ALLUSERSPROFILE%\chocolatey\bin"`
1. Execute `choco feature enable -n=allowGlobalConfirmation` to get rid off additional installation confirmations.
1. Execute `choco install vscode sumatrapdf.install strawberryperl jre8 jabref languagetool` to install necessary tooling.
   Replace `vscode` by `texstudio` if you prefer TeXstudio.
1. In case [PlantUML](http://plantuml.com/) should be used, follow the installation instructions at <https://koppor.github.io/plantuml/> listed at the "pre-conditions" section.
1. For more recommended tooling see <https://github.com/koppor/koppors-chocolatey-scripts>.

##### Recommended setup of MiKTeX

1. Download the basic installer from <http://miktex.org/download>
1. Start it
1. First screen: Read the license conditions and be sure that you really agree.
    - Check "I accept the MiKTeX copying conditions"
    - Click "Next"
1. Second screen: "Shared Installation": Install MiKTeX for: "Only for: `username`".
    - Check first option
    - Click "Next"
1. Third screen: "Installation Directory": Install MiKTeX to: `C:\MiKTeX`. This enabled browsing for documentation at `C:\MiKTeX29\doc\latex`
    - Input "C:\MiKTeX" in the input field
    - Click "Next"
1. Fourth screen: "Settings": Preferred paper: A4 and install missing packages on the fly.
    - First combo box: "A4"
    - Second combo box: "Yes":
    - Click "Next"
1. Fifth screen: Press "Start"
1. Now a window "Executing" appears. It will take about 5 minutes until this is finished.
1. At the last screen: Click "Close"
1. After the installation:
     1. Open `cmd.exe`
     2. Execute `refreshenv` to make MiKTeX's binaries known right after the installation
     3. Execute `mpm --update-db`
     4. Execute `mpm --update`
     5. Execute `mpm --install=tex-gyre` (to resolve `fontspec error: "font-not-found"`, `\setmainfont{TeX Gyre Termes}`)
     6. Execute `mpm --install=tex-gyre-math`
     7. Execute `mpm --install=cm-super`
     8. Execute `initexmf --update-fndb` (ensure that no other MiKTeX tooling such as the [MiKTeX Console](https://miktex.org/howto/miktex-console) is run in parallel - see <https://github.com/MiKTeX/miktex/issues/98#issuecomment-375952270>)
     9. Execute `initexmf --mklinks --force`

#### Installation hints for Ubuntu

- From Ubuntu 18.10 onwards, the basic version of the template works without issues.
  Advanced usages such as cool syntax highlighting with [minted](https://www.ctan.org/pkg/minted) needs more configuration.
  The easiest way is to uninstall the ubuntu package and use [install-tl-ubuntu](https://github.com/scottkosty/install-tl-ubuntu).
  Then, you can follow the instructions given at <http://tex.stackexchange.com/a/55459/9075> to update your texlive distribution.
  If you do not want to have an updated installation, but fiddle around with dirty patching your installation, please follow  <http://tex.stackexchange.com/questions/84624/how-to-upgrade-biblatex-properly>.

Always working solution: the [Docker-based setup](#docker-based-recommended).

## VS Code as LaTeX editor

Use [VS Code](https://code.visualstudio.com/) with the [LaTeX Workshop](https://marketplace.visualstudio.com/items?itemName=James-Yu.latex-workshop) extension.
The recommended extensions and the required `settings.json` entries are given at [VS Code configuration](../README.md#vs-code-configuration) in the main README.
You can also copy the contents of [vscode.settings.json](../vscode.settings.json) to your VS Code settings file.

With the Docker-based setup, LaTeX Workshop can run the tools in the container (an experimental feature of LaTeX Workshop); add the following to `settings.json`:

```json
"latex-workshop.docker.enabled": true,
"latex-workshop.docker.image.latex": "registry.gitlab.com/islandoftex/images/texlive:latest",
```

If you do not want LaTeX Workshop to compile automatically after each change, add the following line and trigger the compilation manually:

```json
"latex-workshop.latex.autoBuild.run": "never",
```

## JabRef for managing literature

Use [JabRef] to manage your bibliography.
In 2026, install the latest beta version from <https://github.com/JabRef/jabref/releases>: the stable version 5.15 is too old.

A comparison to other literature management software is available at <https://ultimate-comparisons.github.io/ultimate-reference-management-software-comparison/>.

## TeXstudio as LaTeX editor (alternative)

If VS Code does not fit your needs, [TeXstudio] is a good alternative.
Windows: `choco install texstudio languagetool`.
For a complete list of LaTeX editors, see [the LaTeX Editors/IDEs question on TeX.SX](http://tex.stackexchange.com/questions/339/latex-editors-ides).

Grammar and spell checking is available at [TeXstudio].
Please download [LanguageTool] and [configure TeXstudio to use it](http://wiki.languagetool.org/checking-la-tex-with-languagetool#toc4).
Note that it is enough to point to `languagetool-server.jar`.
![language-tool-configuration](texstudio-configuration-languagetool.png)

The template is compiled using normal compilation commands.
Your LaTeX environment (such as [TeXstudio]) should take care about the compilation transparently.

If the document needs `--shell-escape` (for PlantUML or Mermaid diagrams, or for minted with TeX Live 2024), its first lines tell TeXstudio to compile with `--shell-escape`.
Then, TeXstudio warns that the compilation command will be overridden.
Please answer `(a) allow for this document`:

![allow --shell-escape for this document](texstudio-confirmation-1.png)

At "Build & View", there will be a question to update to biber.
Please answer `(a) allow for this document`:

![allow biber for this document](texstudio-confirmation-2.png)

When the "Package Installation" dialog pops up at TeXstudio, choose your username at "The package will be installed for:" and uncheck "Always show this dialog before installing packages."
If you want to include .svg graphics, [inkscape] has to be in your path.

**Attention!** The first compilation will take **at least 30 seconds**, because there will be some LaTeX packages installed.

### Using TeXstudio with the Docker image

1. Open Options > Configure TeXstudio > Commands and set
   - "PdfLaTeX" to `docker run --rm -v "DIROFTEXDOCUMENT:/workdir" registry.gitlab.com/islandoftex/images/texlive:latest pdflatex --shell-escape -synctex=1 -interaction=nonstopmode %.tex`,
   - "LuaLaTeX" to `docker run --rm -v "DIROFTEXDOCUMENT:/workdir" registry.gitlab.com/islandoftex/images/texlive:latest lualatex --shell-escape -synctex=1 -interaction=nonstopmode %.tex`, and
   - "Biber" to `docker run --rm -v "DIROFTEXDOCUMENT:/workdir" registry.gitlab.com/islandoftex/images/texlive:latest biber %`.

   Replace `DIROFTEXDOCUMENT` by the directory of your LaTeX document. Example: `/home/user/thesis`.
   On Linux and macOS, you can mount the directory at the same path instead (`-v DIROFTEXDOCUMENT:DIROFTEXDOCUMENT --workdir=DIROFTEXDOCUMENT`).
   Then, the paths in the generated SyncTeX file match your machine, and jumping between source and PDF keeps working.
1. Press "Compile" (<kbd>F6</kbd>) in TeXstudio.

[chocolatey]: https://chocolatey.org/
[inkscape]: https://inkscape.org/
[JabRef]: https://www.jabref.org
[LanguageTool]: https://languagetool.org/
[TeXstudio]: https://www.texstudio.org/
