\babel@toc {english}{}\relax 
\babel@toc {ngerman}{}\relax 
\babel@toc {english}{}\relax 
\contentsline {listing}{\numberline {1}{\ignorespaces Example XML listing using minted}}{30}{listing.86}%
\contentsline {listing}{\numberline {2}{\ignorespaces Example JSON listing using minted}}{31}{listing.93}%
\contentsline {listing}{\numberline {3}{\ignorespaces Java code rendered using minted}}{31}{listing.104}%
\contentsline {listing}{\numberline {4}{\ignorespaces Long Java listing spanning multiple pages}}{32}{listing.237}%
\def \@chapapp {\appendixname }
\providecommand \tocbasic@end@toc@file {}\tocbasic@end@toc@file 
