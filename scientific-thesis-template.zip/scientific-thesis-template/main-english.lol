\babel@toc {english}{}\relax 
\babel@toc {ngerman}{}\relax 
\babel@toc {english}{}\relax 
\contentsline {listing}{\numberline {1}{\ignorespaces Example XML listing using minted}}{38}{listing.95}%
\contentsline {listing}{\numberline {2}{\ignorespaces Example JSON listing using minted}}{38}{listing.102}%
\contentsline {listing}{\numberline {3}{\ignorespaces Java code rendered using minted}}{38}{listing.113}%
\contentsline {listing}{\numberline {4}{\ignorespaces Long Java listing spanning multiple pages}}{40}{listing.246}%
\def \@chapapp {\appendixname }
\providecommand \tocbasic@end@toc@file {}\tocbasic@end@toc@file 
